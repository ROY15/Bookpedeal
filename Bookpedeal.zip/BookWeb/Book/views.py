from django.http import HttpResponse,HttpResponseRedirect
from django.template import loader
from django.views.decorators.csrf import csrf_exempt

import pandas as pd

from Book.models import book_data
from Book.models import notify_me

from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot
import plotly.graph_objs as go

import  smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from statsmodels.tsa.stattools import acf
from statsmodels.tsa.arima_model import ARIMA
from statsmodels.tsa.seasonal import seasonal_decompose

import os



# For decode the value..
@csrf_exempt
def index(request):
   # data_insert()
    context={'Searched_name':'',
             'book_not_found':'',}
    
    user_data=notify_me.user_data_all()
    lst = []
    for i in user_data:
        email_id = i[1]
        alert_price = i[2]
        book_name = i[3].strip()
        notified = i[4]
        if notified == 'T':
            urls=[]
            dis_price = book_data.get_book_price_for_price_check(book_name)
            if len(dis_price) > 0:
                dis_price1 = float(dis_price[0][0])
                if dis_price1 < alert_price:
                    url = dis_price[0][1]
                    notify_got_product(email_id,book_name,url)
                    notify_me.update_is_notified(email_id,book_name)
                
                
                
    book_count = book_data.get_books_count()
    
    context['count_business'] = book_count[0][0]
    context['count_education'] = book_count[1][0]
    context['count_fiction'] = book_count[2][0]
    context['count_non_fiction'] = book_count[3][0]
    context['count_romance'] = book_count[4][0]
    if request.method == 'POST':
        context['Searched_name'] = request.POST['book_name']
        selected_book_details = book_data.get_books(request.POST['book_name'])
        img_list=[]
        for i in selected_book_details[0]:
            img_list.append(i)
        if len(img_list) == 0:
            context['book_not_found'] = "T"
        else:
            context['data']= img_list
        template = loader.get_template('book/book_details.html')
        return HttpResponse(template.render(context, request,))
    
    template = loader.get_template('book/index.html')
    return HttpResponse(template.render(context, request,))
   
@csrf_exempt
def fiction_books(request):
    title_author = book_data.get_all_fiction_books()
    title_author_list=[]
    for i in title_author[0]:
        title_author_list.append(i)
        
    for i in title_author[1]:
        str1= str(i[0])
        title_author_list.append(str1.upper())
        
    img_list=[]
    for i in title_author[0]:
        img_list.append(i)
        
    for i in title_author[1]:
        img_list.append(i)
        
    context={'Searched_name':'Fiction',
             'data':img_list,
             'list_len':len(img_list),
         'title_authhor_list':title_author_list[2],}
    if request.method == 'POST':
        if request.POST['email_id'] != '':
            email_id = request.POST['email_id']
            alert_price = request.POST['alert_price']
            book_name = request.POST['book_name'].strip()
            data_insert_to_notify_table(email_id,alert_price,book_name)
            notify_request_accept(email_id,book_name)
            template = loader.get_template('book/index.html')
            return HttpResponse(template.render(context, request,))
        if request.POST['product_url'] != '':
            T = book_data.count_increment(request.POST['product_url'])
            context['update_data'] = T
            return HttpResponseRedirect(request.POST['product_url'])
            #template = loader.get_template('book/book_details_compare.html')
            #return HttpResponse(template.render(context, request,))
        else:
            context['Searched_name'] = request.POST['book_name']
            init_notebook_mode(connected=True)

            SETTINGS_PATH = os.path.dirname(os.path.dirname(__file__))
           
            path = os.path.join(SETTINGS_PATH, 'Book\\static')
           
            path = path+"\\books_variation.xlsx"
           
            #path = path.replace('\\','/')
           
            #df = pd.read_excel("G:/Aegis Study/Documents/Python/Python Project/BookWeb/Book/static/books_variation.xlsx")
            df = pd.read_excel(path)

            book_name = context['Searched_name'].strip()

            d1 = df[df['title'] == book_name]
            x = d1.date
            y = d1.price
            
            mx = y.max()
            mn = y.min()
            
            trace0 = [go.Scatter(x=x,y=y,mode='lines+markers', fill='tozeroy')]
            fig = go.Figure(data=trace0, layout=go.Layout(title=book_name, xaxis=dict(title='Date', showgrid=False, range=['2019-01-23','2019-02-08']),yaxis=dict(title='Price in INR', range=[mn-50,mx+50])))
            div = plot(fig, show_link=True, output_type='div')
            
            context['graph'] = div
            
            dateparse = lambda dates: pd.datetime.strptime(str(dates), '%d-%m-%Y')
            
            SETTINGS_PATH = os.path.dirname(os.path.dirname(__file__))
           
            path = os.path.join(SETTINGS_PATH, 'Book\\static')
           
            path = path+"\\books_variation.csv"
           
            #path = path.replace('\\','/')
            df=pd.read_csv(path,parse_dates=['date'],index_col='date',date_parser=dateparse,encoding='windows-1252')
            book_name = 'Rich Dad Poor Dad'
            d1 = df[df['title'] == book_name]
            d1.drop('title',inplace=True,axis=1)
            
            
            ts=d1['price']
            expwighted_avg=ts.ewm(halflife=12,adjust=True,min_periods=0).mean()
            ts_log_ewma_diff = ts - expwighted_avg
            ts_log_diff = ts - ts.shift()
            ts_log_diff.dropna(inplace=True)
            lag_acf = acf(ts_log_diff, nlags=20)
            decomposition = seasonal_decompose(ts)
            trend = decomposition.trend
            seasonal = decomposition.seasonal
            residual = decomposition.resid
            ts_log_decompose = residual
            ts_log_decompose.dropna(inplace=True)
            model = ARIMA(ts, order=(0, 1, 2))
            results_MA = model.fit(disp=-1)
            div1 = results_MA.plot_predict(1,21)
            
            context['graph_forcast'] =  results_MA.plot_predict(1,21)
            
# =============================================================================
#             x = d1.date
#             y = d1.price
#             
#             trace1 = go.Scatter(x=x, y=y,mode='lines+markers', fill='tozeroy', marker={'color': 'blue'},name='1st Trace')
#             data=go.Data([trace1])
#             layout=go.Layout(title=book_name, xaxis={'title':'Date'}, yaxis={'title':'Price in IN'})
#             figure=go.Figure(data=data,layout=layout)
#             div = opy.plot(figure, auto_open=False, output_type='div')
#             context['graph'] = div
# =============================================================================
          
            
            selected_book_details = book_data.get_book_details(request.POST['book_name'].strip())
 
            lst_book =[]
            for i in selected_book_details[0]:
                lst_book.append(i)
                
            #context['book_details_final']=lst_book[0]
            context['book_details_final_title'] = lst_book[0][1]
            context['book_details_final_cover_type'] = lst_book[0][3].upper()
            context['book_details_final_gener'] = lst_book[0][4].upper()
            context['book_details_final_img_url'] = lst_book[0][8]
            
            if lst_book[0][2]=='nan':
                context['book_details_final_author'] = "---"
            else:
                context['book_details_final_author'] = lst_book[0][2]
            
            
            context['book_details_final_web_comp_bookswagon'] = "Not Avaliable"
            context['book_details_final_actual_price_bookswagon'] = "-"
            context['book_details_final_discounted_price_bookswagon'] = "-"
            context['book_details_final_product_url__bookswagon'] = ''
            
            context['book_details_final_web_comp_crossword'] = "Not Avaliable"
            context['book_details_final_actual_price_crossword'] = "-"
            context['book_details_final_discounted_price_crossword'] = "-"
            context['book_details_final_product_url__crossword'] = ''
            
            context['book_details_final_web_comp_ebay'] = "Not Avaliable"
            context['book_details_final_actual_price_ebay'] = "-"
            context['book_details_final_discounted_price_ebay'] = "-"
            context['book_details_final_product_url__ebay'] = ''
            
            context['book_details_final_web_comp_Flipkart'] = "Not Avaliable"
            context['book_details_final_actual_price_Flipkart'] = "-"
            context['book_details_final_discounted_price_Flipkart'] = "-"
            context['book_details_final_product_url__Flipkart'] = ''
            
            context['book_details_final_web_comp_booksmela'] = "Not Avaliable"
            context['book_details_final_actual_price_booksmela'] = "-"
            context['book_details_final_discounted_price_booksmela'] = "-"
            context['book_details_final_product_url__booksmela'] = ''
            
            for i in range(0,len(lst_book)):
                if lst_book[i][11] == "bookswagon":
                    context['book_details_final_web_comp_bookswagon'] = lst_book[i][11]
                    context['book_details_final_actual_price_bookswagon'] = lst_book[i][5]
                    context['book_details_final_discounted_price_bookswagon'] = lst_book[i][6]
                    context['book_details_final_product_url__bookswagon'] = lst_book[i][9]
                
                if lst_book[i][11] == "crossword":
                    context['book_details_final_web_comp_crossword'] = lst_book[i][11]
                    context['book_details_final_actual_price_crossword'] = lst_book[i][5]
                    context['book_details_final_discounted_price_crossword'] = lst_book[i][6]
                    context['book_details_final_product_url__crossword'] = lst_book[i][9]
                    
                if lst_book[i][11] == "ebay":
                      context['book_details_final_web_comp_ebay'] = lst_book[i][11]
                      context['book_details_final_actual_price_ebay'] = lst_book[i][5]
                      context['book_details_final_discounted_price_ebay'] = lst_book[i][6]
                      context['book_details_final_product_url__ebay'] = lst_book[i][9]
                    
                if lst_book[i][11] == "Flipkart": 
                    context['book_details_final_web_comp_Flipkart'] = lst_book[i][11]
                    context['book_details_final_actual_price_Flipkart'] = lst_book[i][5]
                    context['book_details_final_discounted_price_Flipkart'] = lst_book[i][6]
                    context['book_details_final_product_url__Flipkart'] = lst_book[i][9]
                
                if lst_book[i][11] == "booksmela": 
                    context['book_details_final_web_comp_booksmela'] = lst_book[i][11]
                    context['book_details_final_actual_price_booksmela'] = lst_book[i][5]
                    context['book_details_final_discounted_price_booksmela'] = lst_book[i][6]
                    context['book_details_final_product_url__booksmela'] = lst_book[i][9]
                    
           
                
            template = loader.get_template('book/book_details_compare.html')
            return HttpResponse(template.render(context, request,))
    
    template = loader.get_template('book/fiction_books.html')
    return HttpResponse(template.render(context, request,))

@csrf_exempt
def non_fiction_books(request):
    title_author = book_data.get_all_non_fiction_books()
    title_author_list=[]
    for i in title_author[0]:
        title_author_list.append(i)
        
    for i in title_author[1]:
        str1= str(i[0])
        title_author_list.append(str1.upper())
        
    img_list=[]
    for i in title_author[0]:
        img_list.append(i)
        
    for i in title_author[1]:
        img_list.append(i)
        
    context={'Searched_name':'Non Fiction(Biography)',
             'data':img_list,
             'list_len':len(img_list),
         'title_authhor_list':title_author_list[2],}
    if request.method == 'POST':
        if request.POST['product_url'] != '':
            context['Searched_name'] = request.POST['product_url']
            return HttpResponseRedirect(request.POST['product_url'])
        else:
            
            context['Searched_name'] = request.POST['book_name']
            selected_book_details = book_data.get_book_details(request.POST['book_name'])
            lst_book =[]
            for i in selected_book_details[0]:
                lst_book.append(i)
                
            
           #context['book_details_final']=lst_book[0]
            context['book_details_final_title'] = lst_book[0][1]
            context['book_details_final_cover_type'] = lst_book[0][3].upper()
            context['book_details_final_gener'] = lst_book[0][4].upper()
            context['book_details_final_img_url'] = lst_book[0][8]
            
            if lst_book[0][2]=='nan':
                context['book_details_final_author'] = "---"
            else:
                context['book_details_final_author'] = lst_book[0][2]
            
            
            context['book_details_final_web_comp_bookswagon'] = "Not Avaliable"
            context['book_details_final_actual_price_bookswagon'] = "-"
            context['book_details_final_discounted_price_bookswagon'] = "-"
            context['book_details_final_product_url__bookswagon'] = ''
            
            context['book_details_final_web_comp_crossword'] = "Not Avaliable"
            context['book_details_final_actual_price_crossword'] = "-"
            context['book_details_final_discounted_price_crossword'] = "-"
            context['book_details_final_product_url__crossword'] = ''
            
            context['book_details_final_web_comp_ebay'] = "Not Avaliable"
            context['book_details_final_actual_price_ebay'] = "-"
            context['book_details_final_discounted_price_ebay'] = "-"
            context['book_details_final_product_url__ebay'] = ''
            
            context['book_details_final_web_comp_Flipkart'] = "Not Avaliable"
            context['book_details_final_actual_price_Flipkart'] = "-"
            context['book_details_final_discounted_price_Flipkart'] = "-"
            context['book_details_final_product_url__Flipkart'] = ''
            
            context['book_details_final_web_comp_booksmela'] = "Not Avaliable"
            context['book_details_final_actual_price_booksmela'] = "-"
            context['book_details_final_discounted_price_booksmela'] = "-"
            context['book_details_final_product_url__booksmela'] = ''
            
            for i in range(0,len(lst_book)):
                if lst_book[i][11] == "bookswagon":
                    context['book_details_final_web_comp_bookswagon'] = lst_book[i][11]
                    context['book_details_final_actual_price_bookswagon'] = lst_book[i][5]
                    context['book_details_final_discounted_price_bookswagon'] = lst_book[i][6]
                    context['book_details_final_product_url__bookswagon'] = lst_book[i][9]
                
                if lst_book[i][11] == "crossword":
                    context['book_details_final_web_comp_crossword'] = lst_book[i][11]
                    context['book_details_final_actual_price_crossword'] = lst_book[i][5]
                    context['book_details_final_discounted_price_crossword'] = lst_book[i][6]
                    context['book_details_final_product_url__crossword'] = lst_book[i][9]
                    
                if lst_book[i][11] == "ebay":
                      context['book_details_final_web_comp_ebay'] = lst_book[i][11]
                      context['book_details_final_actual_price_ebay'] = lst_book[i][5]
                      context['book_details_final_discounted_price_ebay'] = lst_book[i][6]
                      context['book_details_final_product_url__ebay'] = lst_book[i][9]
                    
                if lst_book[i][11] == "Flipkart": 
                    context['book_details_final_web_comp_Flipkart'] = lst_book[i][11]
                    context['book_details_final_actual_price_Flipkart'] = lst_book[i][5]
                    context['book_details_final_discounted_price_Flipkart'] = lst_book[i][6]
                    context['book_details_final_product_url__Flipkart'] = lst_book[i][9]
                
                if lst_book[i][11] == "booksmela": 
                    context['book_details_final_web_comp_booksmela'] = lst_book[i][11]
                    context['book_details_final_actual_price_booksmela'] = lst_book[i][5]
                    context['book_details_final_discounted_price_booksmela'] = lst_book[i][6]
                    context['book_details_final_product_url__booksmela'] = lst_book[i][9]
                    
            template = loader.get_template('book/book_details_compare.html')
            return HttpResponse(template.render(context, request,))
    
    
    template = loader.get_template('book/non_fiction_books.html')
    return HttpResponse(template.render(context, request,))

@csrf_exempt
def education_books(request):
    title_author = book_data.get_all_education_books()
    title_author_list=[]
    for i in title_author[0]:
        title_author_list.append(i)
        
    for i in title_author[1]:
        str1= str(i[0])
        title_author_list.append(str1.upper())
        
    img_list=[]
    for i in title_author[0]:
        img_list.append(i)
        
    for i in title_author[1]:
        img_list.append(i)
        
    context={'Searched_name':'Education',
             'data':img_list,
             'list_len':len(img_list),
         'title_authhor_list':title_author_list[2],}
    if request.method == 'POST':
        if request.POST['product_url'] != '':
            context['Searched_name'] = request.POST['product_url']
            return HttpResponseRedirect(request.POST['product_url'])
        else:
            
            context['Searched_name'] = request.POST['book_name']
            selected_book_details = book_data.get_book_details(request.POST['book_name'])
            lst_book =[]
            for i in selected_book_details[0]:
                lst_book.append(i)
                
            
           #context['book_details_final']=lst_book[0]
            context['book_details_final_title'] = lst_book[0][1]
            context['book_details_final_cover_type'] = lst_book[0][3].upper()
            context['book_details_final_gener'] = lst_book[0][4].upper()
            context['book_details_final_img_url'] = lst_book[0][8]
            
            if lst_book[0][2]=='nan':
                context['book_details_final_author'] = "---"
            else:
                context['book_details_final_author'] = lst_book[0][2]
            
            
            context['book_details_final_web_comp_bookswagon'] = "Not Avaliable"
            context['book_details_final_actual_price_bookswagon'] = "-"
            context['book_details_final_discounted_price_bookswagon'] = "-"
            context['book_details_final_product_url__bookswagon'] = ''
            
            context['book_details_final_web_comp_crossword'] = "Not Avaliable"
            context['book_details_final_actual_price_crossword'] = "-"
            context['book_details_final_discounted_price_crossword'] = "-"
            context['book_details_final_product_url__crossword'] = ''
            
            context['book_details_final_web_comp_ebay'] = "Not Avaliable"
            context['book_details_final_actual_price_ebay'] = "-"
            context['book_details_final_discounted_price_ebay'] = "-"
            context['book_details_final_product_url__ebay'] = ''
            
            context['book_details_final_web_comp_Flipkart'] = "Not Avaliable"
            context['book_details_final_actual_price_Flipkart'] = "-"
            context['book_details_final_discounted_price_Flipkart'] = "-"
            context['book_details_final_product_url__Flipkart'] = ''
            
            context['book_details_final_web_comp_booksmela'] = "Not Avaliable"
            context['book_details_final_actual_price_booksmela'] = "-"
            context['book_details_final_discounted_price_booksmela'] = "-"
            context['book_details_final_product_url__booksmela'] = ''
            
            for i in range(0,len(lst_book)):
                if lst_book[i][11] == "bookswagon":
                    context['book_details_final_web_comp_bookswagon'] = lst_book[i][11]
                    context['book_details_final_actual_price_bookswagon'] = lst_book[i][5]
                    context['book_details_final_discounted_price_bookswagon'] = lst_book[i][6]
                    context['book_details_final_product_url__bookswagon'] = lst_book[i][9]
                
                if lst_book[i][11] == "crossword":
                    context['book_details_final_web_comp_crossword'] = lst_book[i][11]
                    context['book_details_final_actual_price_crossword'] = lst_book[i][5]
                    context['book_details_final_discounted_price_crossword'] = lst_book[i][6]
                    context['book_details_final_product_url__crossword'] = lst_book[i][9]
                    
                if lst_book[i][11] == "ebay":
                      context['book_details_final_web_comp_ebay'] = lst_book[i][11]
                      context['book_details_final_actual_price_ebay'] = lst_book[i][5]
                      context['book_details_final_discounted_price_ebay'] = lst_book[i][6]
                      context['book_details_final_product_url__ebay'] = lst_book[i][9]
                    
                if lst_book[i][11] == "Flipkart": 
                    context['book_details_final_web_comp_Flipkart'] = lst_book[i][11]
                    context['book_details_final_actual_price_Flipkart'] = lst_book[i][5]
                    context['book_details_final_discounted_price_Flipkart'] = lst_book[i][6]
                    context['book_details_final_product_url__Flipkart'] = lst_book[i][9]
                
                if lst_book[i][11] == "booksmela": 
                    context['book_details_final_web_comp_booksmela'] = lst_book[i][11]
                    context['book_details_final_actual_price_booksmela'] = lst_book[i][5]
                    context['book_details_final_discounted_price_booksmela'] = lst_book[i][6]
                    context['book_details_final_product_url__booksmela'] = lst_book[i][9]
                    
            template = loader.get_template('book/book_details_compare.html')
            return HttpResponse(template.render(context, request,))
    
    
    template = loader.get_template('book/education_books.html')
    return HttpResponse(template.render(context, request,))

@csrf_exempt
def romance_books(request):
    title_author = book_data.get_all_romance_books()
    title_author_list=[]
    for i in title_author[0]:
        title_author_list.append(i)
        
    for i in title_author[1]:
        str1= str(i[0])
        title_author_list.append(str1.upper())
        
    img_list=[]
    for i in title_author[0]:
        img_list.append(i)
        
    for i in title_author[1]:
        img_list.append(i)
        
    context={'Searched_name':'Romance',
             'data':img_list,
             'list_len':len(img_list),
         'title_authhor_list':title_author_list[2],}
    if request.method == 'POST':
        if request.POST['product_url'] != '':
            context['Searched_name'] = request.POST['product_url']
            return HttpResponseRedirect(request.POST['product_url'])
        else:
            
            context['Searched_name'] = request.POST['book_name']
            selected_book_details = book_data.get_book_details(request.POST['book_name'])
            lst_book =[]
            for i in selected_book_details[0]:
                lst_book.append(i)
                
            
            #context['book_details_final']=lst_book[0]
            context['book_details_final_title'] = lst_book[0][1]
            context['book_details_final_cover_type'] = lst_book[0][3].upper()
            context['book_details_final_gener'] = lst_book[0][4].upper()
            context['book_details_final_img_url'] = lst_book[0][8]
            
            if lst_book[0][2]=='nan':
                context['book_details_final_author'] = "---"
            else:
                context['book_details_final_author'] = lst_book[0][2]
            
            
            context['book_details_final_web_comp_bookswagon'] = "Not Avaliable"
            context['book_details_final_actual_price_bookswagon'] = "-"
            context['book_details_final_discounted_price_bookswagon'] = "-"
            context['book_details_final_product_url__bookswagon'] = ''
            
            context['book_details_final_web_comp_crossword'] = "Not Avaliable"
            context['book_details_final_actual_price_crossword'] = "-"
            context['book_details_final_discounted_price_crossword'] = "-"
            context['book_details_final_product_url__crossword'] = ''
            
            context['book_details_final_web_comp_ebay'] = "Not Avaliable"
            context['book_details_final_actual_price_ebay'] = "-"
            context['book_details_final_discounted_price_ebay'] = "-"
            context['book_details_final_product_url__ebay'] = ''
            
            context['book_details_final_web_comp_Flipkart'] = "Not Avaliable"
            context['book_details_final_actual_price_Flipkart'] = "-"
            context['book_details_final_discounted_price_Flipkart'] = "-"
            context['book_details_final_product_url__Flipkart'] = ''
            
            context['book_details_final_web_comp_booksmela'] = "Not Avaliable"
            context['book_details_final_actual_price_booksmela'] = "-"
            context['book_details_final_discounted_price_booksmela'] = "-"
            context['book_details_final_product_url__booksmela'] = ''
            
            for i in range(0,len(lst_book)):
                if lst_book[i][11] == "bookswagon":
                    context['book_details_final_web_comp_bookswagon'] = lst_book[i][11]
                    context['book_details_final_actual_price_bookswagon'] = lst_book[i][5]
                    context['book_details_final_discounted_price_bookswagon'] = lst_book[i][6]
                    context['book_details_final_product_url__bookswagon'] = lst_book[i][9]
                
                if lst_book[i][11] == "crossword":
                    context['book_details_final_web_comp_crossword'] = lst_book[i][11]
                    context['book_details_final_actual_price_crossword'] = lst_book[i][5]
                    context['book_details_final_discounted_price_crossword'] = lst_book[i][6]
                    context['book_details_final_product_url__crossword'] = lst_book[i][9]
                    
                if lst_book[i][11] == "ebay":
                      context['book_details_final_web_comp_ebay'] = lst_book[i][11]
                      context['book_details_final_actual_price_ebay'] = lst_book[i][5]
                      context['book_details_final_discounted_price_ebay'] = lst_book[i][6]
                      context['book_details_final_product_url__ebay'] = lst_book[i][9]
                    
                if lst_book[i][11] == "Flipkart": 
                    context['book_details_final_web_comp_Flipkart'] = lst_book[i][11]
                    context['book_details_final_actual_price_Flipkart'] = lst_book[i][5]
                    context['book_details_final_discounted_price_Flipkart'] = lst_book[i][6]
                    context['book_details_final_product_url__Flipkart'] = lst_book[i][9]
                
                if lst_book[i][11] == "booksmela": 
                    context['book_details_final_web_comp_booksmela'] = lst_book[i][11]
                    context['book_details_final_actual_price_booksmela'] = lst_book[i][5]
                    context['book_details_final_discounted_price_booksmela'] = lst_book[i][6]
                    context['book_details_final_product_url__booksmela'] = lst_book[i][9]
                    
                
            template = loader.get_template('book/book_details_compare.html')
            return HttpResponse(template.render(context, request,))
    
    template = loader.get_template('book/romance_books.html')
    return HttpResponse(template.render(context, request,))

@csrf_exempt
def business_books(request):
    title_author = book_data.get_all_business_books()
    title_author_list=[]
    for i in title_author[0]:
        title_author_list.append(i)
        
    for i in title_author[1]:
        str1= str(i[0])
        title_author_list.append(str1.upper())
        
    img_list=[]
    for i in title_author[0]:
        img_list.append(i)
        
    for i in title_author[1]:
        img_list.append(i)
        
    context={'Searched_name':'Business',
             'data':img_list,
             'list_len':len(img_list),
         'title_authhor_list':title_author_list[2],}
    if request.method == 'POST':
        if request.POST['product_url'] != '':
            context['Searched_name'] = request.POST['product_url']
            return HttpResponseRedirect(request.POST['product_url'])
        else:
            
            context['Searched_name'] = request.POST['book_name']
            selected_book_details = book_data.get_book_details(request.POST['book_name'])
            lst_book =[]
            for i in selected_book_details[0]:
                lst_book.append(i)
                
            
           #context['book_details_final']=lst_book[0]
            context['book_details_final_title'] = lst_book[0][1]
            context['book_details_final_cover_type'] = lst_book[0][3].upper()
            context['book_details_final_gener'] = lst_book[0][4].upper()
            context['book_details_final_img_url'] = lst_book[0][8]
            
            if lst_book[0][2]=='nan':
                context['book_details_final_author'] = "---"
            else:
                context['book_details_final_author'] = lst_book[0][2]
            
            
            context['book_details_final_web_comp_bookswagon'] = "Not Avaliable"
            context['book_details_final_actual_price_bookswagon'] = "-"
            context['book_details_final_discounted_price_bookswagon'] = "-"
            context['book_details_final_product_url__bookswagon'] = ''
            
            context['book_details_final_web_comp_crossword'] = "Not Avaliable"
            context['book_details_final_actual_price_crossword'] = "-"
            context['book_details_final_discounted_price_crossword'] = "-"
            context['book_details_final_product_url__crossword'] = ''
            
            context['book_details_final_web_comp_ebay'] = "Not Avaliable"
            context['book_details_final_actual_price_ebay'] = "-"
            context['book_details_final_discounted_price_ebay'] = "-"
            context['book_details_final_product_url__ebay'] = ''
            
            context['book_details_final_web_comp_Flipkart'] = "Not Avaliable"
            context['book_details_final_actual_price_Flipkart'] = "-"
            context['book_details_final_discounted_price_Flipkart'] = "-"
            context['book_details_final_product_url__Flipkart'] = ''
            
            context['book_details_final_web_comp_booksmela'] = "Not Avaliable"
            context['book_details_final_actual_price_booksmela'] = "-"
            context['book_details_final_discounted_price_booksmela'] = "-"
            context['book_details_final_product_url__booksmela'] = ''
            
            for i in range(0,len(lst_book)):
                if lst_book[i][11] == "bookswagon":
                    context['book_details_final_web_comp_bookswagon'] = lst_book[i][11]
                    context['book_details_final_actual_price_bookswagon'] = lst_book[i][5]
                    context['book_details_final_discounted_price_bookswagon'] = lst_book[i][6]
                    context['book_details_final_product_url__bookswagon'] = lst_book[i][9]
                
                if lst_book[i][11] == "crossword":
                    context['book_details_final_web_comp_crossword'] = lst_book[i][11]
                    context['book_details_final_actual_price_crossword'] = lst_book[i][5]
                    context['book_details_final_discounted_price_crossword'] = lst_book[i][6]
                    context['book_details_final_product_url__crossword'] = lst_book[i][9]
                    
                if lst_book[i][11] == "ebay":
                      context['book_details_final_web_comp_ebay'] = lst_book[i][11]
                      context['book_details_final_actual_price_ebay'] = lst_book[i][5]
                      context['book_details_final_discounted_price_ebay'] = lst_book[i][6]
                      context['book_details_final_product_url__ebay'] = lst_book[i][9]
                    
                if lst_book[i][11] == "Flipkart": 
                    context['book_details_final_web_comp_Flipkart'] = lst_book[i][11]
                    context['book_details_final_actual_price_Flipkart'] = lst_book[i][5]
                    context['book_details_final_discounted_price_Flipkart'] = lst_book[i][6]
                    context['book_details_final_product_url__Flipkart'] = lst_book[i][9]
                
                if lst_book[i][11] == "booksmela": 
                    context['book_details_final_web_comp_booksmela'] = lst_book[i][11]
                    context['book_details_final_actual_price_booksmela'] = lst_book[i][5]
                    context['book_details_final_discounted_price_booksmela'] = lst_book[i][6]
                    context['book_details_final_product_url__booksmela'] = lst_book[i][9]
                    
                
            template = loader.get_template('book/book_details_compare.html')
            return HttpResponse(template.render(context, request,))
    
    template = loader.get_template('book/business_books.html')
    return HttpResponse(template.render(context, request,))




def data_insert():
    data_ebay_fiction = pd.read_excel("C:/Users/Dell/Desktop/CSV/final_price_data.xlsx")
    len(data_ebay_fiction)
    print(data_ebay_fiction.head())
    print(data_ebay_fiction.columns)
    for i in range(0,len(data_ebay_fiction)):
        title = data_ebay_fiction.loc[i,'title']
        author = data_ebay_fiction.loc[i,'author']
        cover_type = data_ebay_fiction.loc[i,'cover_type']
        genre = data_ebay_fiction.loc[i,'genre']
        actual_price = data_ebay_fiction.loc[i,'actual_price']
        discounted_price = data_ebay_fiction.loc[i,'discounted_price']
        current_date = data_ebay_fiction.loc[i,'current_date']
        img_url = data_ebay_fiction.loc[i,'img_url']
        product_url = data_ebay_fiction.loc[i,'product_url']
        wed_comp = data_ebay_fiction.loc[i,'web_comp']
        insert_data_book = book_data(title=title,author=author,cover_type=cover_type,genre=genre,actual_price=actual_price,discounted_price=discounted_price,cur_date=current_date,img_url=img_url,product_url=product_url,count=0,wed_comp=wed_comp)
        insert_data_book.save()
        
def data_insert_to_notify_table(user_email,ac_price,book_title):
        already_user = notify_me.is_user_notify_already_book(user_email,book_title)
        if len(already_user) > 0:
            notify_me.update_ac_price(user_email,book_title,ac_price)
            
        else:    
            insert_data_book = notify_me(user_mail = user_email,alert_price = ac_price ,book_title=book_title)
            insert_data_book.save()
            
            
def notify_got_product(user_email,book_name,urls):
    fromaddr = "bookpedeal2019@gmail.com"
    msg = MIMEMultipart()
    msg['From'] = fromaddr
    msg['To'] = user_email
    msg['Subject'] = "Grab your chance to buy "+book_name+" at lowest price !!"
    
    body = """\
    <html>
      <head></head>
      <body>
        <p><h4>Hi!</h4>
           <h4> Flipkart is back with the lowest price you were looking to buy ' """+book_name+""" ' . </h4>
           <a href=" """+urls+""" ">Please click on this link to buy now</a>
        </p>
        <div style="top:30px; position:relative;">
            Thanking you for your support,<br>
            <div style="font-size:20px;"><b> bookपेdeal™ </b></div>
        </div>
      </body>
    </html>
    """
    
    msg.attach(MIMEText(body, 'html'))
    
    
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.login(fromaddr, "bpd1234%")
    text = msg.as_string()
    server.sendmail(fromaddr, user_email, text)
    server.quit()

        
def notify_request_accept(user_email,book_name):
    fromaddr = "bookpedeal2019@gmail.com"
    msg = MIMEMultipart()
    msg['From'] = fromaddr
    msg['To'] = user_email
    msg['Subject'] = "Request generated !!"
    
    body = """\
    <html>
      <head></head>
      <body>
    <p><h4>Hi!</h4>
      <h4> As per your request we will notify you whenever '"""+book_name+""" ' is available at price lower than alert price set by you. </h4> <br>
    </p>
    <div style="top:30px; position:relative;">
        Thanking you for your support,<br>
            <div style="font-size:20px;"><b> bookपेdeal™ </b></div>
        </div>
      </body>
    </html>
    """
    
    msg.attach(MIMEText(body, 'html'))
    
    
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.login(fromaddr, "bpd1234%")
    text = msg.as_string()
    server.sendmail(fromaddr, user_email, text)
    server.quit()
    

