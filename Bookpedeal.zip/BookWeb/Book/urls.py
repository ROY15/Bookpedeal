from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('fiction_books.html', views.fiction_books, name='fiction_books'),
    path('non_fiction_books.html', views.non_fiction_books, name='non_fiction_books'),
    path('education_books.html', views.education_books, name='education_books'),
    path('romance_books.html', views.romance_books, name='romance_books'),
    path('business_books.html', views.business_books, name='business_books'),
]
